﻿using _321_Lab05_3;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Diagnostics;

namespace pigeonthapae
{
    public class Game1 : Game
    {
        //setting
        private int bound_X = 1100;
        private int bound_Y = 600; //y start 308
        private int bird_price = 10;
        private int boss_health = 40;
        private int boss_health_per_level = 20;
        private int Time_spawn_dek = 60;
        private int bar_width = 262;
        static public int money = 20;
        private Vector2 where_dekspawn = new Vector2(-150,300);
        private float time_police = 30;
        private float cooldown_police = 30;
        private float time_sign = 5;
        private float cooldown_sign = 5;
        private Vector2 area_sign = new Vector2(180, 180);

        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;
        private SpriteFont uid_font;
        private KeyboardState _keyboardState, oldstate;
        private MouseState _mousestate, oldms,lastms;
        private Texture2D pigeon_texture, bg, kid_texure, barcolor, buy_bird,food_texture,police_texture,sign_texture,buy_police,buy_sign;
        private Texture2D pigeon_fly;
        private List<Pigeon> bird = new List<Pigeon>();
        private List<kid> dek = new List<kid>();
        private List<food> bfood = new List<food>();
        private List<Police> _police = new List<Police>();
        private List<Sign> _sign = new List<Sign>();
        private float elapsed;
        private Random rnd = new Random();
        private bool attacked = false;
        private float time_pick = 0;
        private Rectangle bar,button_bird,button_sign,button_police,button_car,none_area,none_area2,none_area3;
        private float time_money, cal_money;
        private string type_click = "food";
        private float c_sign, c_police;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            _graphics.PreferredBackBufferWidth = 1200;
            _graphics.PreferredBackBufferHeight = 800;
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            none_area = new Rectangle(0, 0, 1200, 308);
            none_area2 = new Rectangle(0, 618, 1200, 74);
            none_area3 = new Rectangle(0, 618, 648, 181);
            bar = new Rectangle(68, 673, bar_width, 10);
            button_bird = new Rectangle(0, 450, 144, 148);
            button_police = new Rectangle(648, 693, 150, 108);
            button_sign = new Rectangle(797, 693, 190, 108);
            button_car = new Rectangle(987, 693, 250, 108);
            c_sign = cooldown_sign;
            c_police = cooldown_police;
            base.Initialize();
        }

        protected override void LoadContent()
        {
            pigeon_texture = Content.Load<Texture2D>("bird/bird_main");
            pigeon_fly = Content.Load<Texture2D>("bird/bird_fly");
            kid_texure = Content.Load<Texture2D>("dek/dek");
            food_texture = Content.Load<Texture2D>("bird/food");
            police_texture = Content.Load<Texture2D>("police/police");
            sign_texture = Content.Load<Texture2D>("sign");
            buy_police = Content.Load<Texture2D>("police_button");
            buy_sign = Content.Load<Texture2D>("sign_button");
            buy_bird = Content.Load<Texture2D>("birdbutton");
            barcolor = Content.Load<Texture2D>("bar");
            uid_font = Content.Load<SpriteFont>("textfont_uid");
            bg = Content.Load<Texture2D>("bg");
            _spriteBatch = new SpriteBatch(GraphicsDevice);
            bird.Add(new Pigeon(pigeon_texture, pigeon_fly, new Vector2(rnd.Next(10,bound_X), rnd.Next(310, bound_Y))));
            bird.Add(new Pigeon(pigeon_texture, pigeon_fly, new Vector2(rnd.Next(10, bound_X), rnd.Next(310, bound_Y))));
            bird.Add(new Pigeon(pigeon_texture, pigeon_fly, new Vector2(rnd.Next(10, bound_X), rnd.Next(310, bound_Y))));
        }

        protected override void Update(GameTime gameTime)
        {
            //end game
            if(bird.Count <= 0)
            {
            //    Exit();
            }




            //time
            elapsed = (float)gameTime.ElapsedGameTime.TotalSeconds;
            time_pick += (float)gameTime.ElapsedGameTime.TotalSeconds;
            time_money += (float)gameTime.ElapsedGameTime.TotalSeconds;
            //cooldown skill
            c_police -= (float)gameTime.ElapsedGameTime.TotalSeconds;
            c_sign -= (float)gameTime.ElapsedGameTime.TotalSeconds;
            if(c_police <= 0)
            {
                c_police = 0;
            }
            if (c_sign <= 0)
            {
                c_sign = 0;
            }


            //state mouse keyboard
            _mousestate = Mouse.GetState();
            _keyboardState = Keyboard.GetState();


            //cheat
            if (_keyboardState.IsKeyDown(Keys.A) & oldstate.IsKeyUp(Keys.A))
            {
                money += 500;
            }
            if (_keyboardState.IsKeyDown(Keys.U) & oldstate.IsKeyUp(Keys.U))
            {
                _police.Add(new Police(police_texture, time_police));
            }

            if (_keyboardState.IsKeyDown(Keys.I) & oldstate.IsKeyUp(Keys.I))
            {
                type_click = "sign_select";
            }


            //debug
            if (_keyboardState.IsKeyDown(Keys.Q) & oldstate.IsKeyUp(Keys.Q))
            {
                Console.WriteLine("elapsed = " + elapsed);
                Console.WriteLine("money = " + money);
                Console.WriteLine("Time = " + time_pick);
                Console.WriteLine("X = "+_mousestate.X+" Y ="+_mousestate.Y);
                Console.WriteLine("Police Cooldown = " + c_police);
                Console.WriteLine("Sign Cooldown = " + c_sign);
                Console.WriteLine("Type = " + type_click);

            }


            //spawn dek
            if (time_pick >= Time_spawn_dek || _keyboardState.IsKeyDown(Keys.H) & oldstate.IsKeyUp(Keys.H))
            {
                dek.Add(new kid(kid_texure, where_dekspawn, boss_health, barcolor));
                attacked = true;
            }


            //update bird
            foreach (Pigeon ppbird in bird)
            {
                ppbird.move(none_area);
                //randomlocation & check bird go outside
                ppbird.updatebird(bound_X, bound_Y, elapsed, bfood);
                if(ppbird.pos.Y <= 0-pigeon_texture.Height)
                {
                    bird.Remove(ppbird);
                    break;
                }
                //check bird_with_food
                foreach (food mini_food in bfood)
                {
                    if (ppbird.checkfood(mini_food.hitbox))
                    {
                        bfood.Remove(mini_food);
                        break;
                    }
                }
            }


            //check attacked
            if (attacked)
            {

                time_pick = 0;
                //check all dek die
                if(dek.Count <= 0)
                {
                    attacked = false;
                    boss_health += boss_health_per_level;
                }
                //update dek , location dek, move, check_with_bird
                foreach (kid deks in dek)
                {

                    //select location & check if dek go out
                    deks.selectbird(bird, elapsed);
                    if(deks.pos.Y >= _graphics.GraphicsDevice.Viewport.Height)
                    {
                        dek.Remove(deks);
                        break;
                    }
                    deks.move(_sign, none_area);
                    //check_with_bird
                    foreach (Pigeon checkinterbird in bird)
                    {
                        checkinterbird.checkintersect(deks.hitbox);
                    }
                    
                    //check_with_police & update
                    foreach(Police mini_police in _police)
                    {
                        deks.damaged(mini_police.hitbox, elapsed);
                    }

                }
            }
            else
            {
                bar = new Rectangle(68, 673, (int)(bar_width - (bar_width * (time_pick / Time_spawn_dek))), 10);
            }

            //change type click
            if(type_click != "sign_select")
            {
                if (button_bird.Contains(_mousestate.X, _mousestate.Y))
                {
                    type_click = "buybird";
                }
                else if(none_area.Contains(_mousestate.X, _mousestate.Y) || none_area2.Contains(_mousestate.X, _mousestate.Y) || none_area3.Contains(_mousestate.X, _mousestate.Y))
                {
                    type_click = "None";
                }
                else if (button_sign.Contains(_mousestate.X, _mousestate.Y))
                {
                    type_click = "sign";
                }
                else if (button_police.Contains(_mousestate.X, _mousestate.Y))
                {
                    type_click = "police";
                }
                else if (button_car.Contains(_mousestate.X, _mousestate.Y))
                {
                    type_click = "car";
                }
                else if(_mousestate.X >= _graphics.GraphicsDevice.Viewport.Width || _mousestate.Y > _graphics.GraphicsDevice.Viewport.Height || _mousestate.X <= 0 || _mousestate.Y <= 0)
                {
                    type_click = "None";
                }
                else
                {
                    type_click = "food";
                }
            }
            //click screen
            if (_mousestate.LeftButton == ButtonState.Pressed && oldms.LeftButton == ButtonState.Released)
            {
                if(type_click == "food")
                {
                    if (attacked)
                    {
                        foreach(kid mini_dek in dek)
                        {
                            if (!mini_dek.damaged(_mousestate, oldms) & money >= 1)
                            {
                                bfood.Add(new food(food_texture, 1, 1, 1, new Vector2(_mousestate.X, _mousestate.Y)));
                                money -= 1;
                            }
                        }
                    }
                    else
                    {
                        if(money >= 1)
                        {
                            bfood.Add(new food(food_texture, 1, 1, 1, new Vector2(_mousestate.X, _mousestate.Y)));
                            money -= 1;
                        }
                    }
                }
                else if(type_click == "buybird" & money >= bird_price)
                {
                    bird.Add(new Pigeon(pigeon_texture, pigeon_fly, new Vector2(rnd.Next(10, bound_X), rnd.Next(310, bound_Y))));
                    money -= 10;
                }
                else if (type_click == "sign" & c_sign == 0)
                {
                    type_click = "sign_select";
                }
                else if (type_click == "sign_select")
                {
                    if(!none_area.Contains(_mousestate.X, _mousestate.Y) & !none_area2.Contains(_mousestate.X, _mousestate.Y) & !none_area3.Contains(_mousestate.X, _mousestate.Y) & !button_police.Contains(_mousestate.X, _mousestate.Y) & !button_bird.Contains(_mousestate.X, _mousestate.Y) & !button_car.Contains(_mousestate.X, _mousestate.Y) & !button_sign.Contains(_mousestate.X, _mousestate.Y))
                    {
                        if(_mousestate.X < _graphics.GraphicsDevice.Viewport.Width & _mousestate.Y < _graphics.GraphicsDevice.Viewport.Height & _mousestate.X > 0 & _mousestate.Y > 0)
                        {
                            c_sign = cooldown_sign;
                            type_click = "food";
                            _sign.Add(new Sign(sign_texture, new Vector2(_mousestate.X - (area_sign.X / 2), _mousestate.Y - (area_sign.Y / 2)), time_sign, area_sign));
                        }
                    }
                }
                else if (type_click == "dek")
                {
                    //feedback
                }
                else if(type_click == "police" & c_police == 0)
                {
                    _police.Add(new Police(police_texture, time_police));
                    c_police = cooldown_police;
                }

            }


            //update police

            foreach (Police mini_police in _police)
            {
                mini_police.selecttarget(dek, elapsed);
                mini_police.update();
                if (mini_police.time_out)
                {
                    if(mini_police.pos.X >= _graphics.GraphicsDevice.Viewport.Width)
                    {
                        _police.Remove(mini_police);
                        break;
                    }
                }
            }

            //update sign
            foreach(Sign mini_sign in _sign)
            {
                if (mini_sign.time_out(elapsed))
                {
                    _sign.Remove(mini_sign);
                    break;
                }
            }

          


            //destroy food
            foreach(food mini_food in bfood)
            {
                if (mini_food.selfdestroy(elapsed))
                {
                    bfood.Remove(mini_food);
                    break;
                }
            }

            
            //update money
            if(time_money >= 1)
            {
                time_money = 0;
                cal_money += 1;
            }
            //money (bird*0.5) +1
            //bird cal*10
            //item stage*บลาๆๆๆ และ cooldown++


            //old item
            oldms = _mousestate;
            oldstate = _keyboardState;
            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);
            _spriteBatch.Begin();
            _spriteBatch.Draw(bg,_graphics.GraphicsDevice.Viewport.Bounds,Color.White);
            //food
            foreach (food mini_food in bfood)
            {
                mini_food.Draw(_spriteBatch);
            }
            //bird
            foreach (Pigeon ppbird in bird)
            {
                ppbird.Pigeondraw(_spriteBatch,uid_font);

            }
            //police
            foreach (Police mini_police in _police)
            {
                mini_police.Draw(_spriteBatch);
            }
            //kid
            foreach (kid deks in dek)
            {
                deks.kiddraw(_spriteBatch);
            }
            //sign
            foreach(Sign mini_sign in _sign)
            {
                mini_sign.Draw(_spriteBatch);
            }
            if(type_click == "sign_select")
            {
                if(!none_area.Contains(_mousestate.X, _mousestate.Y) & !none_area2.Contains(_mousestate.X, _mousestate.Y) & !none_area3.Contains(_mousestate.X, _mousestate.Y) & !button_police.Contains(_mousestate.X, _mousestate.Y) & !button_bird.Contains(_mousestate.X, _mousestate.Y) & !button_car.Contains(_mousestate.X, _mousestate.Y) & !button_sign.Contains(_mousestate.X, _mousestate.Y) & _mousestate.X < _graphics.GraphicsDevice.Viewport.Width & _mousestate.Y < _graphics.GraphicsDevice.Viewport.Height & _mousestate.X > 0 & _mousestate.Y > 0)
                {
                    _spriteBatch.Draw(sign_texture, new Vector2(_mousestate.X - (area_sign.X / 2), _mousestate.Y - (area_sign.Y / 2)), Color.White);
                    lastms = _mousestate;
                }
                //else
                //{
                //    _spriteBatch.Draw(sign_texture, new Vector2(lastms.X - (area_sign.X / 2), lastms.Y - (area_sign.Y / 2)), Color.White);
                //}
            }
            //bar
            if (!attacked)
            {
                _spriteBatch.Draw(barcolor, bar, Color.LimeGreen);

            }
            //ui
            
            _spriteBatch.Draw(buy_bird, button_bird, Color.White);
            _spriteBatch.Draw(buy_sign, button_sign, Color.White);
            _spriteBatch.Draw(buy_police, button_car, Color.White);
            _spriteBatch.Draw(buy_police, button_police, Color.White);
            _spriteBatch.DrawString(uid_font, Convert.ToString(money),new Vector2(915,147), Color.White);
            _spriteBatch.End();
            
            base.Draw(gameTime);
        }
    }
}