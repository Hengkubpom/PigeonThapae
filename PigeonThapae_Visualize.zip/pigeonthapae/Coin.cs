﻿using _321_Lab05_3;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pigeonthapae
{
    internal class Coin
    {
        public int worth = 5;
        private Vector2 pos;
        private float time_pick = 0;

        public Coin(int frameCount, int frameRow, int framesPerSec, Vector2 pos)
        {
            this.pos = pos;
        }

        public void Coindraw(SpriteBatch _batch,SpriteFont font)
        {
            _batch.DrawString(font, "+5", pos, Color.White);
        }

        public bool selfdestroy(float elapsed)
        {
            time_pick += elapsed;
            if(time_pick >= 3)
            {
                return true;
            }
            return false;
        }
    }
}
