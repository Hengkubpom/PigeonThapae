﻿
using var game = new pigeonthapae.Game1();
game.Run();
